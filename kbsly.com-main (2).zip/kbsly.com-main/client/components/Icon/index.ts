export { default } from "./Icon";
